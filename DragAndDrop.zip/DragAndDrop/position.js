function Position(x, y) {

	this.x = x;
    this.y = y;
	
	if(this.x == null) {
		this.x = 0;
	}
	if(this.y == null) {
		this.y = 0;
	}
	
}